/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author Gustavo Mendonça
 */
public class Disciplina {
    
    private int idDisciplina;
    private String nomeDisciplna;
    private Professor professor;
    private Turma turma;

    /**
     *
     * @param idDisciplina
     * @param nomeDisciplna
     * @param professor
     * @param turma
     */
    public Disciplina(int idDisciplina, String nomeDisciplna, Professor professor, Turma turma) {
        this.idDisciplina = idDisciplina;
        this.nomeDisciplna = nomeDisciplna;
        this.professor = professor;
        this.turma = turma;
    }

    public Disciplina() {
    }
   
}
