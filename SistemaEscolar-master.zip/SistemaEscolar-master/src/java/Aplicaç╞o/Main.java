/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicação;

import Modelo.Modelo;



/**
 *
 * @author Gustavo Mendonça
 */
public class Main {
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        modelo.addAluno(); //Realizando teste de banco de dados para Aluno
    }
}
